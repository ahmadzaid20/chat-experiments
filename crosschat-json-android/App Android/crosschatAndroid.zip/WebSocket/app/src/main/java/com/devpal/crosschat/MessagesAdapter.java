package com.devpal.crosschat;

public class MessagesAdapter {
    public void addMessage(String text) {
    }
}
